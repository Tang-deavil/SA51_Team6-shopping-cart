﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Assignment_2.Models;
using System.Data.SqlClient;

namespace Assignment_2.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        string connectionString = "Server=DESKTOP-589MI59;" + "Database=ShoppingCart;" + "Integrated Security=true";

        string userId = "1001";

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult Index()
        {
            List<Purchases> purchases = FinalList(); // data of past purchases will be added into a list here
            ViewData["purchases"] = purchases;
            return View();
        }
        public List<Purchases> FinalList() // Combines the purchases and activation list
        {
            List<Purchases> purchases = GetPurchases();
            List<ActivationCode> codes = GetActivationCodes();

            foreach (Purchases purchase in purchases)
            {
                foreach (ActivationCode code in codes)
                {
                    if (code.orderId == purchase.orderId && code.productId == purchase.productId)
                    {
                        purchase.activationCode.Add((string)code.activationCode);
                    }
                }
            }
            return purchases;
        }

        public List<ActivationCode> GetActivationCodes() // creates a list of activation codes based on requested userId
        {
            List<ActivationCode> codes = new List<ActivationCode>();

            string sql = @"select * from ActivationCode Where UserId = " + userId;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    ActivationCode code = new ActivationCode()
                    {
                        activationCode = (string)reader["ActivationCode"],
                        orderId = (int)reader["OrderId"],
                        productId = (int)reader["ProductId"]
                    };
                    codes.Add(code);
                }
            }
            return codes;
        }



        public List<Purchases> GetPurchases() // create a list of purchases
        {
            string sql = @"select OD.OrderId, OD.ProductId, Quantity, OD.UserId, PurchaseDate, [Image], Title, [Description], Link 
                            FROM
                            (
                             (Select OD.OrderId, OD.ProductId, OD.Quantity, OD.UserId from OrderDetails OD) OD
                             full outer join
                             (select PurchaseDate, O.orderId from [Order] O) O on OD.OrderId = O.OrderId 
                             full outer join
                             (select [image], title, [description], Link, P.ProductId From Product P) P on  OD.ProductId = P.ProductId
                            ) where OD.UserId = " + userId;


            List<Purchases> purchases = new List<Purchases>();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Purchases purchase = new Purchases()
                    {
                        orderId = (int)reader["OrderId"],
                        productId = (int)reader["ProductId"],
                        quantity = (int)reader["Quantity"],
                        purchaseDate = (DateTime)reader["PurchaseDate"],
                        image = (string)reader["Image"],
                        title = (string)reader["Title"],
                        description = (string)reader["Description"],
                        link = (string)reader["Link"],
                    };
                    purchases.Add(purchase);
                }
                conn.Close();
            }

            return purchases;
        }


        public IActionResult Privacy()
        {
            return View();
        }

    }
}
