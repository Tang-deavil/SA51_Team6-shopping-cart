﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment_2.Models
{
    public class ActivationCode
    {
        public string activationCode { get; set; }
        public int orderId { get; set; }
        public int productId { get; set; }

    }
}
