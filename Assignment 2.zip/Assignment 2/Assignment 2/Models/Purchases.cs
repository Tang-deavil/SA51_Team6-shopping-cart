﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment_2.Models
{
    public class Purchases
    {
        // contains the paramters of the purchases
        //public Purchases()
        //{
        //    List<string> activationCode = new List<string>();
        //}
        public int orderId { set; get; }
        public int productId { set; get; }
        public int quantity { set; get; }
        public DateTime purchaseDate { set; get; }
        public string image { set; get; }
        public string title { set; get; }
        public string description { set; get; }
        public string link { set; get; }
        //public List<string> activationCode { set; get; }
        public List<string> activationCode = new List<string>();



        /*
        public string image { set; get; }
        public string description { set; get; }
        public string url { set; get; }
        public string date { set; get; }
        public int quantity { set; get; }
        public string[] code { set; get; }
        */
    }
}
